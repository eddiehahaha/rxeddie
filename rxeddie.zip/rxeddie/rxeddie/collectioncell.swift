//
//  collectioncell.swift
//  rxeddie
//
//  Created by Man Kit Tsui on 3/28/20.
//  Copyright © 2020 Man Kit Tsui. All rights reserved.
//


import Foundation
import UIKit
import Gemini

class HoroscopeCollectionViewCells : GeminiCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var imageLbl: UILabel!
}
