//
//  URLapi + extension.swift
//  rxeddie
//
//  Created by Man Kit Tsui on 3/28/20.
//  Copyright © 2020 Man Kit Tsui. All rights reserved.
//

import Foundation
import UIKit
import RxSwift
import RxCocoa

struct Resource<T> {
    let url: URL
}


extension URL {
    
    static func urlForHoroscope(sign : String) -> URL? {
        return URL(string: "http://horoscope-api.herokuapp.com/horoscope/today/\(sign)")
    }
}

extension URLRequest {
    
    static func load<T: Decodable>(resource: Resource<T>) -> Observable<T> {
        
        return Observable.from([resource.url])
            .flatMap { url -> Observable<Data> in
                let request = URLRequest(url: url)
                return URLSession.shared.rx.data(request: request)
            }.map { data -> T in
                return try JSONDecoder().decode(T.self, from: data)
        }.asObservable()
    }
}
