//
//  HoroscopeModel.swift
//  rxeddie
//
//  Created by Man Kit Tsui on 3/28/20.
//  Copyright © 2020 Man Kit Tsui. All rights reserved.
//

import Foundation

extension Horoscope {
    
    static var empty: Horoscope {
        return Horoscope(date: "", horoscope: "", sunsign: "")
    }
    
}

struct Horoscope: Codable {
    let date: String
    let horoscope: String
    let sunsign : String
}
